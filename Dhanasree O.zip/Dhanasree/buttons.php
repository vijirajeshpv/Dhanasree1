<?php
  include_once "inc/header.php";
  include_once "inc/sidebar.php";
?>
	
	<button></button>
	
<?php
include_once "inc/footer.php";
?>